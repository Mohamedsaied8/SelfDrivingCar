var player = require('play-sound')(opts = {})
player.play('/tmp/chaching.mp3', function(err){}) // $ mplayer foo.mp3 
