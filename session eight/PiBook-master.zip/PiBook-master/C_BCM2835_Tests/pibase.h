/*
 * pibase.h
 *
 *  Created on: Dec 30, 2015
 *      Author: kolban
 */

#ifndef PIBASE_H_
#define PIBASE_H_



int getFunction(int pin);
char *functionToString(int function);

#endif /* PIBASE_H_ */
