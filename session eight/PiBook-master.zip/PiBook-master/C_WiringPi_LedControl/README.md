Test the use of MAX7219 LED controls for matrix and 7 segment displays.
Primarily a port of the Arduino project called wayoda/LedControl

https://github.com/wayoda/LedControl